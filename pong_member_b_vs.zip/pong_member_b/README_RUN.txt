﻿《PONG》成员 B（美术与表现）Visual Studio 独立运行包
================================================

一、运行步骤
1. 确认本机已安装 EasyX 图形库（https://easyx.cn/，安装程序会自动配置到 VS 2019/2022）。
2. 解压本压缩包到纯英文路径（例如 D:\pong_member_b）。
3. 双击打开 pong_render_preview.sln。
4. 顶部平台选 x64（或 x86），按 Ctrl+F5（或点击“本地 Windows 调试器”）直接编译运行。
   - 若使用 Visual Studio 2019 打开提示工具集 v143 未安装：
     在解决方案资源管理器中右键项目 -> “重定向项目” -> 确认即可自动切换为 v142。

二、预览快捷键
- T      : 循环切换 4 套主题（纯色 / 模拟 / Matrix / Control）
- 1 - 4  : 切换 4 套台面漆色预设（ITTF 蓝 / 经典绿 / 深红 / 黑金）
- K      : 循环切换球拍与球体皮肤
- Space  : 模拟发力击球火花与屏幕震动
- F      : 模拟得分边缘闪屏
- Esc    : 退出预览

三、提交到团队 GitHub 仓库时
只需提交 src/render.h 与 src/render.cpp（test_render_preview.cpp 可放 tests/ 目录），
shared_types.h 以团队成员 D 冻结的版本为准。
