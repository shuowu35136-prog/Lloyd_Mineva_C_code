#pragma once

#include <graphics.h>
#include "shared_types.h"

// render.h —— 成员 B（美术与表现）对外接口
// 职责：纯几何矢量绘制球桌、球拍/球皮肤、主题、四要素配色、拖尾、粒子对象池与得分闪屏。
// 约束：只读 GameState，不修改任何物理数据；零外部位图依赖；无每帧堆内存分配。

enum class PaddleSkin { Solid, NeonPulse, ScanStripe };
enum class BallSkin   { Solid, Segmented, EnergyCore };

struct RenderConfig {
    // 场地与实体几何参数（对应 params.json，杜绝魔法数字）
    int   winW          = 1280;
    int   winH          = 720;
    int   tableW        = 1280;
    int   tableH        = 712;
    int   tableY0       = 4;
    int   borderPx      = 9;
    int   centerLinePx  = 2;
    int   netPostSize   = 8;
    int   paddleW       = 12;
    int   paddleH       = 70;
    int   paddleMarginX = 48;
    float ballRadius    = 9.5f;

    // 主题、皮肤与四要素自定义配色
    Theme      theme            = Theme::Solid;
    PaddleSkin leftSkin         = PaddleSkin::Solid;
    PaddleSkin rightSkin        = PaddleSkin::Solid;
    BallSkin   ballSkin         = BallSkin::EnergyCore;
    COLORREF   tableColor       = RGB(24, 68, 128);    // 默认 ITTF 蓝
    COLORREF   leftPaddleColor  = RGB(238, 244, 255);
    COLORREF   rightPaddleColor = RGB(255, 112, 92);
    COLORREF   ballColor        = RGB(255, 232, 115);
    bool       enableFx         = true;
};

struct Particle {
    float    x, y;
    float    vx, vy;
    float    life;
    float    maxLife;
    COLORREF color;
    bool     active;
};

struct TrailPoint {
    float x, y;
    float spin;
    bool  valid;
};

struct RenderFx {
    static constexpr int MAX_PARTICLES = 200;
    static constexpr int MAX_TRAIL     = 18;
    static constexpr int MATRIX_COLS   = 24;

    RenderConfig cfg;
    Particle     particles[MAX_PARTICLES];
    TrailPoint   trail[MAX_TRAIL];
    int          trailHead     = 0;
    float        flashTimer    = 0.0f;
    int          flashSide     = -1;     // 0 = 左方得分，1 = 右方得分
    bool         ballBoosted   = false;  // 发力击球高亮状态
    float        matrixY[MATRIX_COLS];
    float        pyramidAngle  = 0.0f;
};

// 初始化渲染特效状态（清空对象池与拖尾）
void render_init(RenderFx& fx);

// 切换 4 套台面漆色预设：0=ITTF蓝, 1=经典绿, 2=深红, 3=黑金
void render_apply_table_preset(RenderConfig& cfg, int presetIndex);

// 每渲染帧（60 FPS）更新拖尾、粒子、得分闪屏与主题背景动画
void render_update_fx(RenderFx& fx, const GameState& g, float dt);

// 击球瞬间沿碰撞法线方向生成火花粒子（普通 8 个，发力 12 个）
void render_spawn_sparks(RenderFx& fx, float x, float y, float nx, float ny, bool boosted);

// 得分瞬间触发 120 ms 边缘闪屏（scorerSide: 0=左方, 1=右方）
void render_trigger_flash(RenderFx& fx, int scorerSide);

// 策划案第 6 节标准渲染入口：只读 GameState，震动偏移 (shakeX, shakeY) 仅作用于绘制
void render_frame(const GameState& g, const RenderFx& fx, int shakeX, int shakeY);
