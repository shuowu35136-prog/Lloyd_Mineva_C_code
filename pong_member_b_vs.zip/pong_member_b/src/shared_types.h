#pragma once

// shared_types.h —— 第一周冻结的共享 POD 与枚举（对照策划案 v0.3 第 6 节）
// 说明：各模块只允许 include 本文件与公共接口头，禁止横向 include 其他模块实现。

enum class Mode       { Menu, Single, Vs, Paused, Result };
enum class Difficulty { Easy, Normal, Hard };
enum class Strategy   { Conservative, Aggressive, Adaptive, Taunt };
enum class Sfx        { BallHit, BallHitBoost, Score, Out, MenuMove, MenuConfirm, Win, Lose };
enum class GameEvent  { None, Hit, Boost, Score, Out, MatchEnd, Dialogue, Shake };
enum class Theme      { Solid, Simulation, Matrix, Control, Custom };

struct Vec2 {
    float x;
    float y;
};

struct BallState {
    Vec2  pos;
    Vec2  vel;
    float spin;   // 正值 = 球向上弯，范围 [-3.0, +3.0]
};

struct PaddleState {
    float y;      // 球拍中心 Y 坐标（px）
    float vy;     // 球拍纵向速度（px/s）
};

struct GameState {
    BallState   ball;
    PaddleState paddles[2];   // [0] 左侧玩家，[1] 右侧玩家或 IOI
    int         score[2];
    Mode        mode;
    Difficulty  diff;
    unsigned    rally;        // 当前回合连续击球次数
    float       time;         // 累计运行时间（秒）
};

struct InputSnapshot {
    bool p1_up, p1_down, p1_boost;
    bool p2_up, p2_down, p2_boost;
    bool serve, pause;
};

struct StateHistory {
    GameState frames[24];     // 最近 0.2 s @ 120 Hz
    int       count;
};
