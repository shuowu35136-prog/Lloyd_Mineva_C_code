// test_render_preview.cpp —— 成员 B 独立静态/动态预览测试入口（对应附录 A.2）
// 用法：在 Visual Studio（已安装 EasyX）中新建空项目，加入 shared_types.h / render.h / render.cpp / 本文件即可直接运行。
// 快捷键：T 切换主题 | 1-4 切换台面漆色 | K 切换皮肤 | Space 模拟发力击球火花与震动 | F 模拟得分闪屏 | Esc 退出

#include <graphics.h>
#include <windows.h>
#include <cmath>
#include "render.h"

static bool key_pressed_once(int vk, bool& prev) {
    bool now = (GetAsyncKeyState(vk) & 0x8000) != 0;
    bool hit = now && !prev;
    prev = now;
    return hit;
}

int main() {
    RenderFx fx;
    render_init(fx);

    GameState g = {};
    g.ball.pos      = { 640.0f, 356.0f };
    g.ball.vel      = { 540.0f, 210.0f };
    g.ball.spin     = 1.8f;
    g.paddles[0].y  = 356.0f;
    g.paddles[1].y  = 356.0f;
    g.mode          = Mode::Single;
    g.rally         = 2;

    initgraph(fx.cfg.winW, fx.cfg.winH);
    BeginBatchDraw();

    bool prevT = false, prevK = false, prevSp = false, prevF = false;
    int  themeIdx = 0, skinIdx = 0;
    float shakeTimer = 0.0f;
    const float dt = 1.0f / 60.0f;

    while (!(GetAsyncKeyState(VK_ESCAPE) & 0x8000)) {
        if (key_pressed_once('T', prevT)) {
            themeIdx = (themeIdx + 1) % 4;
            fx.cfg.theme = static_cast<Theme>(themeIdx);
        }
        if (key_pressed_once('K', prevK)) {
            skinIdx = (skinIdx + 1) % 3;
            fx.cfg.leftSkin  = static_cast<PaddleSkin>(skinIdx);
            fx.cfg.rightSkin = static_cast<PaddleSkin>(skinIdx);
            fx.cfg.ballSkin  = static_cast<BallSkin>(skinIdx);
        }
        for (int k = 0; k < 4; ++k) {
            if (GetAsyncKeyState('1' + k) & 0x8000) render_apply_table_preset(fx.cfg, k);
        }
        if (key_pressed_once(VK_SPACE, prevSp)) {
            render_spawn_sparks(fx, g.ball.pos.x, g.ball.pos.y, -g.ball.vel.x, 0.0f, true);
            shakeTimer = 0.10f;
            ++g.rally;
        }
        if (key_pressed_once('F', prevF)) {
            render_trigger_flash(fx, g.ball.vel.x > 0 ? 0 : 1);
            g.rally = 0;
        }

        // 简易模拟球与球拍运动，方便预览拖尾与碰撞火花
        g.time += dt;
        g.ball.pos.x += g.ball.vel.x * dt;
        g.ball.pos.y += g.ball.vel.y * dt;
        g.paddles[0].y = 356.0f + 160.0f * std::sin(g.time * 1.4f);
        g.paddles[1].y = 356.0f + 160.0f * std::cos(g.time * 1.1f);

        if (g.ball.pos.x < 60.0f || g.ball.pos.x > fx.cfg.tableW - 60.0f) {
            g.ball.vel.x = -g.ball.vel.x;
            render_spawn_sparks(fx, g.ball.pos.x, g.ball.pos.y, g.ball.vel.x > 0 ? 1.0f : -1.0f, 0.0f, false);
            ++g.rally;
        }
        if (g.ball.pos.y < 20.0f || g.ball.pos.y > fx.cfg.tableH - 20.0f) {
            g.ball.vel.y = -g.ball.vel.y;
            g.ball.spin *= 0.8f;
        }

        int sx = 0, sy = 0;
        if (shakeTimer > 0.0f) {
            shakeTimer -= dt;
            sx = static_cast<int>(std::sin(g.time * 180.0f) * 5.0f);
            sy = static_cast<int>(std::cos(g.time * 210.0f) * 5.0f);
        }

        render_update_fx(fx, g, dt);
        render_frame(g, fx, sx, sy);
        FlushBatchDraw();
        Sleep(16);
    }

    EndBatchDraw();
    closegraph();
    return 0;
}
