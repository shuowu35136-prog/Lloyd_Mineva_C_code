#include "render.h"
#include <cmath>
#include <tchar.h>

namespace {

constexpr float kPi           = 3.14159265f;
constexpr float kFlashDur     = 0.12f;   // 得分闪屏 120 ms
constexpr float kSparkLife    = 0.28f;
constexpr float kMaxSpinRef   = 3.0f;
constexpr float kBaseSpeedRef = 520.0f;

int clamp_u8(int v) {
    return v < 0 ? 0 : (v > 255 ? 255 : v);
}

COLORREF scale_color(COLORREF c, float s) {
    int r = clamp_u8(static_cast<int>(GetRValue(c) * s));
    int g = clamp_u8(static_cast<int>(GetGValue(c) * s));
    int b = clamp_u8(static_cast<int>(GetBValue(c) * s));
    return RGB(r, g, b);
}

COLORREF blend_color(COLORREF a, COLORREF b, float t) {
    t = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
    int r = clamp_u8(static_cast<int>(GetRValue(a) + (GetRValue(b) - GetRValue(a)) * t));
    int g = clamp_u8(static_cast<int>(GetGValue(a) + (GetGValue(b) - GetGValue(a)) * t));
    int bl = clamp_u8(static_cast<int>(GetBValue(a) + (GetBValue(b) - GetBValue(a)) * t));
    return RGB(r, g, bl);
}

COLORREF resolve_table_color(const RenderConfig& cfg) {
    if (cfg.theme == Theme::Matrix)  return RGB(8, 36, 18);
    if (cfg.theme == Theme::Control) return RGB(34, 10, 14);
    if (cfg.theme == Theme::Simulation) return RGB(20, 74, 134);
    return cfg.tableColor;
}

void draw_theme_bg(const RenderFx& fx, int ox, int oy) {
    const RenderConfig& c = fx.cfg;
    setbkcolor(c.theme == Theme::Control ? RGB(14, 6, 8) : RGB(12, 15, 22));
    cleardevice();

    if (c.theme == Theme::Matrix) {
        setbkmode(TRANSPARENT);
        settextcolor(RGB(28, 120, 56));
        settextstyle(14, 0, _T("Consolas"));
        int stepX = c.winW / RenderFx::MATRIX_COLS;
        for (int i = 0; i < RenderFx::MATRIX_COLS; ++i) {
            TCHAR ch[2] = { static_cast<TCHAR>(_T('0') + (i % 10)), 0 };
            outtextxy(i * stepX + 8 + ox, static_cast<int>(fx.matrixY[i]) + oy, ch);
        }
    } else if (c.theme == Theme::Control) {
        float cx = c.winW * 0.5f + ox;
        float cy = c.winH * 0.44f + oy;
        float w  = 110.0f * std::fabs(std::cos(fx.pyramidAngle)) + 36.0f;
        POINT tri[3] = {
            { static_cast<int>(cx - w), static_cast<int>(cy - 75) },
            { static_cast<int>(cx + w), static_cast<int>(cy - 75) },
            { static_cast<int>(cx),     static_cast<int>(cy + 125) }
        };
        setfillcolor(RGB(8, 8, 10));
        setlinecolor(RGB(115, 26, 26));
        setlinestyle(PS_SOLID, 2);
        fillpolygon(tri, 3);
    }
}

void draw_table(const RenderFx& fx, int ox, int oy) {
    const RenderConfig& c = fx.cfg;
    COLORREF base = resolve_table_color(c);
    int x0 = ox, y0 = c.tableY0 + oy;
    int x1 = x0 + c.tableW, y1 = y0 + c.tableH;

    // 外框与纯色上漆台面
    setfillcolor(RGB(18, 22, 30));
    solidrectangle(x0 - 4, y0 - 4, x1 + 4, y1 + 4);
    setfillcolor(base);
    solidrectangle(x0, y0, x1, y1);

    // 3 条固定同色系漆面高光条
    setfillcolor(scale_color(base, 1.12f));
    solidrectangle(x0 + 180, y0 + c.borderPx, x0 + 270, y1 - c.borderPx);
    solidrectangle(x1 - 270, y0 + c.borderPx, x1 - 180, y1 - c.borderPx);
    setfillcolor(scale_color(base, 0.92f));
    solidrectangle(x0 + c.tableW / 2 - 90, y0 + c.borderPx, x0 + c.tableW / 2 + 90, y1 - c.borderPx);

    // 四周 9 px 白边线、中线与球网（含两端网柱）
    COLORREF lineCol = (c.theme == Theme::Matrix) ? RGB(70, 220, 110) : RGB(242, 245, 250);
    setlinecolor(lineCol);
    setlinestyle(PS_SOLID, c.borderPx);
    rectangle(x0 + c.borderPx / 2, y0 + c.borderPx / 2, x1 - c.borderPx / 2, y1 - c.borderPx / 2);

    int midX = x0 + c.tableW / 2;
    int midY = y0 + c.tableH / 2;
    setlinestyle(PS_SOLID, c.centerLinePx);
    line(x0 + c.borderPx, midY, x1 - c.borderPx, midY);
    line(midX, y0, midX, y1);

    setfillcolor(lineCol);
    int p = c.netPostSize / 2;
    solidrectangle(midX - p, y0 - p, midX + p, y0 + p);
    solidrectangle(midX - p, y1 - p, midX + p, y1 + p);
}

void draw_paddle(const RenderFx& fx, int side, float centerY, float t, int ox, int oy) {
    const RenderConfig& c = fx.cfg;
    int cx = (side == 0 ? c.paddleMarginX : c.tableW - c.paddleMarginX) + ox;
    int cy = static_cast<int>(centerY) + c.tableY0 + oy;
    int hw = c.paddleW / 2, hh = c.paddleH / 2;
    COLORREF col = (side == 0) ? c.leftPaddleColor : c.rightPaddleColor;
    PaddleSkin skin = (side == 0) ? c.leftSkin : c.rightSkin;

    if (c.theme == Theme::Matrix) {
        setlinecolor(RGB(90, 255, 130));
        setfillcolor(RGB(45, 230, 95));
        setlinestyle(side == 0 ? PS_SOLID : PS_DASH, 2);
        fillrectangle(cx - hw, cy - hh, cx + hw, cy + hh);
        return;
    }
    if (c.theme == Theme::Control) {
        int jitter = (side == 1) ? (static_cast<int>(t * 60) % 3 - 1) : 0;
        col = (side == 0) ? RGB(205, 232, 255) : RGB(245, 72, 48);
        setfillcolor(col);
        solidrectangle(cx - hw + jitter, cy - hh, cx + hw + jitter, cy + hh);
        return;
    }
    if (c.theme == Theme::Simulation) {
        setfillcolor(RGB(210, 42, 42));
        solidrectangle(cx - hw, cy - hh, cx + hw, cy - hh / 3);
        setfillcolor(RGB(245, 245, 245));
        solidrectangle(cx - hw, cy - hh / 3, cx + hw, cy + hh / 3);
        setfillcolor(RGB(30, 32, 36));
        solidrectangle(cx - hw, cy + hh / 3, cx + hw, cy + hh);
        return;
    }

    // 纯色主题下的 3 套皮肤：纯色 / 霓虹脉冲 / 扫光条纹
    float pulse = (skin == PaddleSkin::NeonPulse) ? (0.85f + 0.15f * std::sin(t * 8.0f)) : 1.0f;
    setfillcolor(scale_color(col, pulse));
    solidrectangle(cx - hw, cy - hh, cx + hw, cy + hh);
    if (skin == PaddleSkin::ScanStripe) {
        int bandY = cy - hh + (static_cast<int>(t * 90) % c.paddleH);
        setfillcolor(RGB(255, 255, 255));
        solidrectangle(cx - hw, bandY, cx + hw, bandY + 4);
    }
}

COLORREF compute_ball_color(const GameState& g, const RenderFx& fx) {
    if (fx.cfg.theme == Theme::Matrix)  return RGB(120, 255, 140);
    if (fx.cfg.theme == Theme::Control) return (static_cast<int>(g.time * 12) % 2 == 0)
                                               ? RGB(245, 245, 250) : RGB(255, 75, 55);
    if (g.rally >= 3) {
        float hue = static_cast<float>((45 + g.rally * 18) % 360);
        return HSVtoRGB(hue, 0.72f, 1.0f);
    }
    return fx.cfg.ballColor;
}

void draw_trail(const GameState& g, const RenderFx& fx, int ox, int oy) {
    if (!fx.cfg.enableFx) return;
    float speed = std::hypot(g.ball.vel.x, g.ball.vel.y);
    int maxShow = static_cast<int>((speed / kBaseSpeedRef) * 8.0f);
    if (maxShow > RenderFx::MAX_TRAIL) maxShow = RenderFx::MAX_TRAIL;
    COLORREF tableCol = resolve_table_color(fx.cfg);
    COLORREF baseCol  = compute_ball_color(g, fx);

    for (int i = 0; i < maxShow; ++i) {
        int idx = (fx.trailHead - 1 - i + RenderFx::MAX_TRAIL) % RenderFx::MAX_TRAIL;
        const TrailPoint& tp = fx.trail[idx];
        if (!tp.valid) continue;
        float ratio = 1.0f - static_cast<float>(i) / static_cast<float>(maxShow + 1);
        COLORREF spinTint = (tp.spin > 0.2f) ? RGB(80, 225, 255)
                          : (tp.spin < -0.2f ? RGB(255, 110, 210) : baseCol);
        COLORREF c = blend_color(tableCol, blend_color(baseCol, spinTint, 0.55f), ratio * 0.75f);
        int r = static_cast<int>(fx.cfg.ballRadius * (0.35f + 0.55f * ratio));
        setfillcolor(c);
        solidcircle(static_cast<int>(tp.x) + ox, static_cast<int>(tp.y) + fx.cfg.tableY0 + oy, r);
    }
}

void draw_ball(const GameState& g, const RenderFx& fx, int ox, int oy) {
    const RenderConfig& c = fx.cfg;
    int bx = static_cast<int>(g.ball.pos.x) + ox;
    int by = static_cast<int>(g.ball.pos.y) + c.tableY0 + oy;
    int r  = static_cast<int>(c.ballRadius + 0.5f);

    // 固定偏移的球体投影
    setfillcolor(scale_color(resolve_table_color(c), 0.52f));
    solidellipse(bx - r + 5, by - r + 7, bx + r + 5, by + r + 7);

    // 球体皮肤
    COLORREF col = compute_ball_color(g, fx);
    setfillcolor(col);
    solidcircle(bx, by, r);

    if (c.ballSkin == BallSkin::Segmented) {
        setlinecolor(scale_color(col, 0.55f));
        setlinestyle(PS_SOLID, 2);
        line(bx - r + 2, by, bx + r - 2, by);
    } else if (c.ballSkin == BallSkin::EnergyCore && std::fabs(g.ball.spin) > 0.35f) {
        setfillcolor(RGB(255, 255, 255));
        solidcircle(bx, by, r / 2);
    }

    // 切球或发力时的高亮描边
    if (fx.ballBoosted || std::fabs(g.ball.spin) > 0.8f) {
        setlinecolor(fx.ballBoosted ? RGB(255, 95, 60) : RGB(120, 240, 255));
        setlinestyle(PS_SOLID, fx.ballBoosted ? 3 : 2);
        circle(bx, by, r + 2);
    }
}

void draw_particles_and_flash(const RenderFx& fx, int ox, int oy) {
    const RenderConfig& c = fx.cfg;
    if (c.enableFx) {
        for (int i = 0; i < RenderFx::MAX_PARTICLES; ++i) {
            const Particle& p = fx.particles[i];
            if (!p.active) continue;
            float t = p.life / p.maxLife;
            setfillcolor(scale_color(p.color, 0.35f + 0.65f * t));
            solidcircle(static_cast<int>(p.x) + ox, static_cast<int>(p.y) + c.tableY0 + oy, t > 0.5f ? 3 : 2);
        }
    }
    if (fx.flashTimer > 0.0f && fx.flashSide >= 0) {
        float k = fx.flashTimer / kFlashDur;
        setlinecolor(scale_color(RGB(255, 245, 160), k));
        setlinestyle(PS_SOLID, 6);
        int edgeX = (fx.flashSide == 0) ? (c.tableW - 4 + ox) : (4 + ox);
        line(edgeX, c.tableY0 + oy, edgeX, c.tableY0 + c.tableH + oy);
    }
}

} // namespace

void render_init(RenderFx& fx) {
    for (int i = 0; i < RenderFx::MAX_PARTICLES; ++i) fx.particles[i].active = false;
    for (int i = 0; i < RenderFx::MAX_TRAIL; ++i)     fx.trail[i].valid = false;
    for (int i = 0; i < RenderFx::MATRIX_COLS; ++i)   fx.matrixY[i] = static_cast<float>((i * 47) % 720);
    fx.trailHead    = 0;
    fx.flashTimer   = 0.0f;
    fx.flashSide    = -1;
    fx.ballBoosted  = false;
    fx.pyramidAngle = 0.0f;
}

void render_apply_table_preset(RenderConfig& cfg, int presetIndex) {
    static const COLORREF kPresets[4] = {
        RGB(24, 68, 128),  // 0: ITTF 蓝
        RGB(22, 92, 58),   // 1: 经典绿
        RGB(110, 26, 36),  // 2: 深红
        RGB(32, 30, 26)    // 3: 黑金
    };
    cfg.tableColor = kPresets[(presetIndex < 0 ? 0 : presetIndex) % 4];
}

void render_spawn_sparks(RenderFx& fx, float x, float y, float nx, float ny, bool boosted) {
    int count = boosted ? 12 : 8;
    float baseAng = std::atan2(ny, nx);
    int spawned = 0;

    for (int i = 0; i < RenderFx::MAX_PARTICLES && spawned < count; ++i) {
        if (fx.particles[i].active) continue;
        float spread = ((spawned - count * 0.5f) / static_cast<float>(count)) * (kPi * 0.75f);
        float speed  = (boosted ? 280.0f : 170.0f) + static_cast<float>((spawned * 37) % 90);
        fx.particles[i] = {
            x, y,
            std::cos(baseAng + spread) * speed,
            std::sin(baseAng + spread) * speed,
            kSparkLife, kSparkLife,
            boosted ? RGB(255, 130, 65) : RGB(255, 240, 170),
            true
        };
        ++spawned;
    }
    fx.ballBoosted = boosted;
}

void render_trigger_flash(RenderFx& fx, int scorerSide) {
    fx.flashSide   = scorerSide;
    fx.flashTimer  = kFlashDur;
    fx.ballBoosted = false;
}

void render_update_fx(RenderFx& fx, const GameState& g, float dt) {
    fx.trail[fx.trailHead] = { g.ball.pos.x, g.ball.pos.y, g.ball.spin, true };
    fx.trailHead = (fx.trailHead + 1) % RenderFx::MAX_TRAIL;

    for (int i = 0; i < RenderFx::MAX_PARTICLES; ++i) {
        Particle& p = fx.particles[i];
        if (!p.active) continue;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.life -= dt;
        if (p.life <= 0.0f) p.active = false;
    }
    if (fx.flashTimer > 0.0f) fx.flashTimer -= dt;
    fx.pyramidAngle += dt * 0.6f;
    for (int i = 0; i < RenderFx::MATRIX_COLS; ++i) {
        fx.matrixY[i] += (60.0f + (i % 4) * 20.0f) * dt;
        if (fx.matrixY[i] > fx.cfg.winH) fx.matrixY[i] = 0.0f;
    }
}

void render_frame(const GameState& g, const RenderFx& fx, int shakeX, int shakeY) {
    draw_theme_bg(fx, shakeX, shakeY);
    draw_table(fx, shakeX, shakeY);
    draw_trail(g, fx, shakeX, shakeY);
    draw_paddle(fx, 0, g.paddles[0].y, g.time, shakeX, shakeY);
    draw_paddle(fx, 1, g.paddles[1].y, g.time, shakeX, shakeY);
    draw_ball(g, fx, shakeX, shakeY);
    draw_particles_and_flash(fx, shakeX, shakeY);
}
